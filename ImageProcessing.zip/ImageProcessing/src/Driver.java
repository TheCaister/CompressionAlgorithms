import com.thecaister.imageprocessing.ImageProcessing;

public class Driver {
    public static void main(String[] args) {
        ImageProcessing.GreyScale("fortnite");
    }
}
